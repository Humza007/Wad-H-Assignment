
<?php
require_once("db.php");
$sql = "SELECT * FROM users ORDER BY userId DESC";
$result = mysqli_query($conn,$sql);


?>





<html>
<head>
<title>Upload image and store in database</title>
<link rel="stylesheet" type="text/css" href="styles.css" />


<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>

<div style="autocomplete">
<form name="frmUser" method="POST" action="upload.php" enctype="multipart/form-data">


<table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">

<tr class="tableheader">


<ul>
 
 <li><img id="image" src="images/sound.png" width="60" height="50" alt="SoundCloud Logo"/><li>
 <li>
  <a href="http://soundcloud.com/" class="sc-logo" title="Go to SoundCloud.com">SoundCloud</a>
</li>







  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#stream">Stream</a></li>
  <li><a href="#collection">Collection</a></li>


 
  
  <input class="headerSearch__input sc-input g-all-transitions-30" 
  placeholder="Search for artists, bands"
  type="search" name="q" autocomplete="off" aria-label="Search"
  aria-autocomplete="list" aria-owns="searchMenuList">
  
<li><a href="login_user.php">Sign in</a></li>
<li><a href="add_user.php">Create account</a></li>
<li><a href="songs.php">Upload</a></li>
<li><a href="album.php">Album</a></li>
 </ul> 











</tr>
<br>

<tr>



<td><input type="text" name="Album_name"  placeholder="Album name" class="txtField"><td>

</tr>

<td><input type="file" name="file"><td>
</tr>
<td><input type="submit" name="submit" value="Upload" class="btnSubmit"><td>

</tr>
</table>
</div>
</form>

<div class="gallery">

<?php

// Get images from the database

$query ="SELECT * FROM album ORDER BY uploaded_on DESC";
			 $con=mysqli_connect('localhost','root','','users');
               $insert=mysqli_query($con,$query);
if($insert->num_rows > 0){
    while($row = $insert->fetch_assoc()){
        $imageURL = 'uploads/'.$row["file_name"];
?>
    <img src="<?php echo $imageURL; ?>" alt="" />
<?php }
}
 ?>
</div>
</body></html>