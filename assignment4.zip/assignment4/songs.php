
<?php
require_once("db.php");
$sql = "SELECT * FROM users ORDER BY userId DESC";
$result = mysqli_query($conn,$sql);


?>





<html>
<head>
<title>Upload image and store in database</title>
<link rel="stylesheet" type="text/css" href="styles.css" />


<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>

<div style="autocomplete">
<form name="frmUser" method="POST" action="songs.php" enctype="multipart/form-data">


<table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">

<tr class="tableheader">


<ul>
 
 <li><img id="image" src="images/sound.png" width="60" height="50" alt="SoundCloud Logo"/><li>
 <li>
  <a href="http://soundcloud.com/" class="sc-logo" title="Go to SoundCloud.com">SoundCloud</a>
</li>







  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#stream">Stream</a></li>
  <li><a href="#collection">Collection</a></li>


 
  
  <input class="headerSearch__input sc-input g-all-transitions-30" 
  placeholder="Search for artists, bands"
  type="search" name="q" autocomplete="off" aria-label="Search"
  aria-autocomplete="list" aria-owns="searchMenuList">
  
<li><a href="login_user.php">Sign in</a></li>
<li><a href="add_user.php">Create account</a></li>
<li><a href="songs.php">Upload</a></li>
<li><a href="album.php">Album</a></li>

 </ul> 











</tr>
<br>

<tr>



<td><input type="text" name="song_name"  placeholder="Song Name" class="txtField"><td>

</tr>
<td><input type="text" name="song_runTime"  placeholder="Song time" class="txtField"><td>

</tr>

<td><input type="file" name="audio_path" placeholder="Song audio file"><td>
</tr>
<td><input type="text" name="Album_name" placeholder="Song album name"><td>
</tr>
<td><input type="submit" name="submit" value="Upload" class="btnSubmit">

<input type="submit" name="play" value=" play " class="btnSubmit"><td>

</tr>

   
</table>
</div>
</form>
<?php
// Include the database configuration file



if(isset($_POST["submit"]) && !empty($_FILES["audio_path"]["name"]))
{
$statusMsg = '';

// File upload path
$targetDir = "uploads/";
$Audio_path=basename($_FILES["audio_path"]["name"]);
$targetFilePath = $targetDir . $Audio_path;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

    // Allow certain file formats
    $allowTypes = array('mp3');
    if(in_array($fileType,$allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["audio_path"]["tmp_name"], $targetFilePath)){
            // Insert song file name into database
            $query ="INSERT into songs (audio_path,song_name, uploaded_on,Album_name) VALUES ('".$targetFilePath."','". $_POST["song_name"] . "', NOW(),'". $_POST["Album_name"] . "')";
			 $con=mysqli_connect('localhost','root','','users');
               $insert=mysqli_query($con,$query);
            if($insert){
                $statusMsg = "The file ".$Audio_path. " has been uploaded successfully.";
				
				
            }else{
                $statusMsg = "File upload failed, please try again.";
            } 
        }else{
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }else{
        $statusMsg = 'Sorry, only mp3 are allowed to upload.';
    }
}else{
    //$statusMsg = 'Please select a file to upload.';
}

// Display status message
//echo $statusMsg;
if(isset($_POST["play"])){
$query ="SELECT * FROM songs";
			 $con=mysqli_connect('localhost','root','','users');
               $insert=mysqli_query($con,$query);
			   while($row=mysqli_fetch_array($insert))
			   {
				   echo'<a href="songs.php?name='.$row['audio_path'].'">'.$row['audio_path'].'</a>';
				   echo"<br/>";
			   }
			   
}
	
?>

<div class="gallery">
<tr>
<center>

<audio controls>

<source src=" <?php echo $_GET["name"]; ?>" type ="audio/mpeg">
</source>

</audio>
</center>
</tr>
</div>
</body></html>