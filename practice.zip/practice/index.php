
<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>

<form name="frmUser" method="POST" action="">


<table border="10" cellpadding="5" cellspacing="5" width="200"  class="tblSaveForm">



<tr>

<td><input type="text" name="userName"placeholder="Enter Url" class="txtField"></td>
</tr>

<tr>
<td colspan="2"><input type="submit" name="submit" value="submit" class="btnSubmit"></td>

</tr>
</table>
</form>
<h3 id="domain">Domain:</h1>
<?php
if( isset($_POST['submit']) )
{
    $val1 = ($_POST['userName']);
    
	

    
    preg_match("/^(?:https?:\/\/)?(?:[^@\/\n]+@)?(?:www\.)?([^:\/\n]+)/", $val1,$matches_out);
	
    echo" $matches_out[1]";

}
?>
</body>
</html>